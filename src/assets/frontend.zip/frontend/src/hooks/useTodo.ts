import { useEffect, useState, type FormEvent } from "react";

export interface Todo {
  id: number;
  title: string;
  done: boolean;
}

async function getTodos(): Promise<Todo[]> {
  try {
    const response = await fetch("http://localhost:3000/todos");
    const json = await response.json();
    return json;
  } catch (error) {
    console.error(error);
    alert("Ocorreu um erro ao buscar os todos.");
    return [];
  }
}

export const useTodo = () => {
  const [todoList, setTodoList] = useState<Todo[]>([]);
  const [filter, setFilter] = useState<"all" | "active" | "completed">("all");
  const [refresh, setRefresh] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchTodos = async () => {
      const todos = await getTodos();

      setTodoList(todos);
    };

    fetchTodos();
  }, [refresh]);

  const addTodo = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const formData = new FormData(event.currentTarget);
    const todoItem = formData.get("todo") as string;
    event.currentTarget.reset();

    if (!todoItem.trim()) return;
    try {
      setLoading(true);
      await fetch("http://localhost:3000/todos", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: todoItem,
          done: false,
        }),
      });

      setRefresh(!refresh);

      setFilter("all");
      setLoading(false);
    } catch (error) {
      console.error(error);
      alert("Ocorreu um erro ao adicionar o todo.");
      setLoading(false);
    }
  };

  const toggleTodoCompleted = (id: number) => {
    try {
      setLoading(true);
      const toggleTodo = async (value: boolean) => {
        await fetch(`http://localhost:3000/todos/${id}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            done: value,
          }),
        });
        setRefresh(!refresh);
        setLoading(false);
      };

      const todo = todoList.find((todo) => todo.id === id);
      if (!todo) return;
      toggleTodo(!todo.done);

    } catch (error) {
      console.error(error);
      alert("Ocorreu um erro ao atualizar o todo.");
      setLoading(false);
    }
  };

  const filteredTodos = todoList.filter((todo) => {
    if (filter === "active") return !todo.done;
    if (filter === "completed") return todo.done;
    return true;
  });

  const clearCompleted = async () => {
    try {
      setLoading(true);
      const todosToDelete = todoList.filter((todo) => todo.done);

      if (todosToDelete.length === 0) return;
      await Promise.all(todosToDelete.map((todo) => deleteItem(todo.id)));
      setTodoList((prev) => prev.filter((todo) => !todo.done));
      setLoading(false);
    } catch (error) {
      console.error(error);
      alert("Ocorreu um erro ao limpar os todos.");
      setLoading(false);
    }
  };

  const deleteItem = async (id: number) => {
    try {
      setLoading(true);
      await fetch(`http://localhost:3000/todos/${id}`, {
        method: "DELETE",
      });
      setRefresh((prev) => !prev);
      setLoading(false);
    } catch (error) {
      console.error(error);
      alert("Ocorreu um erro ao limpar o todo");
      setLoading(false);
    }
  };

  return {
    addTodo,
    toggleTodoCompleted,
    filteredTodos,
    clearCompleted,
    setFilter,
    filter,
    refresh,
    setRefresh,
    deleteItem,
    loading,
  };
};
