import TodoForm from "./components/TodoForm";
import TodoHeader from "./components/TodoHeader";
import TodoList from "./components/TodoList";
import { TodoContainer } from "./components/TodoContainer";
import { useTodo } from "./hooks/useTodo";

function App() {
  const {
    filteredTodos,
    addTodo,
    toggleTodoCompleted,
    setFilter,
    filter,
    clearCompleted,
    deleteItem,
  } = useTodo();

  return (
    <TodoContainer>
      <TodoHeader />
      <TodoForm addTodo={addTodo} />
      <TodoList
        todoList={filteredTodos}
        toggleTodoCompleted={toggleTodoCompleted}
        setFilter={setFilter}
        filter={filter}
        clearCompleted={clearCompleted}
        deleteItem={deleteItem}
      />
    </TodoContainer>
  );
}

export default App;
